var bleno = require('bleno');

var BlenoPrimaryService = bleno.PrimaryService;

var ReqGenericAccessService = require('./GenericAccessService');
var ReqDeviceInformationService = require('./DeviceInformationService');
var ReqFirmwareService = require('./FirmwareService');
var ReqAlertNotificationService = require('./AlertNotificationService');
var ReqImmediateAlertService = require('./ImmediateAlertService');
var ReqHeartRateService = require('./HeartRateService');
var ReqHuamiFee0Service = require('./HuamiFee0Service');
var ReqHuamiFee1Service = require('./HuamiFee1Service');
var ReqHuamiVendorSpecificService = require('./HuamiVendorSpecificService');

var GenericAccessService = new ReqGenericAccessService();
var DeviceInformationService = new ReqDeviceInformationService();
var FirmwareService = new ReqFirmwareService();
var AlertNotificationService = new ReqAlertNotificationService();
var ImmediateAlertService = new ReqImmediateAlertService();
var HeartRateService = new ReqHeartRateService();
var HuamiFee0Service = new ReqHuamiFee0Service();
var HuamiFee1Service = new ReqHuamiFee1Service();
var HuamiVendorSpecificService = new ReqHuamiVendorSpecificService();

console.log('Bleno - Mi Band 4');

var deviceName = 'Mi Smart Band 4';
//var scanData = new Buffer(...); // maximum 31 bytes
var scanData = new Buffer('10094D6920536D6172742042616E6420340302E0FE','hex')
//var advertisementData = new Buffer('020106','hex'); // Flags
//var advertisementData = new Buffer('1BFF570102FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF02D1EF14DB4C13','hex'); // Manufacturer
//var advertisementData = new Buffer('10094D6920536D6172742042616E642034','hex'); // Complete Local Name
//var advertisementData = new Buffer('0302E0FE','hex'); // Incomplete List of Service UUIDs

var advertisementData = new Buffer('0201061BFF570102FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF02D1EF14DB4C13','hex');

bleno.on('stateChange', function(state) {
	console.log('on -> stateChange: ' + state);

	if (state === 'poweredOn') {
		//bleno.startAdvertising(deviceName);
		bleno.startAdvertisingWithEIRData(advertisementData, scanData);
	} else {
		bleno.stopAdvertising();
	}
});

bleno.on('advertisingStart', function(error) {
	console.log('on -> advertisingStart: ' + (error ? 'error ' + error : 'success'));

	if (!error) {
		bleno.setServices([
			//GenericAccessService
			DeviceInformationService,
			FirmwareService,
			AlertNotificationService,
			ImmediateAlertService,
			HeartRateService,
			HuamiFee0Service,
			HuamiFee1Service,
			HuamiVendorSpecificService
		]);
	}
});
