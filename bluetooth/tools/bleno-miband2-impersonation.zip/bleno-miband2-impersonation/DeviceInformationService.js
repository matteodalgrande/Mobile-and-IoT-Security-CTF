var util = require('util');
var bleno = require('bleno');

var SerialNumberStringCharacteristic = require('./Characteristics/SerialNumberStringCharacteristic');
var HardwareRevisionStringCharacteristic = require('./Characteristics/HardwareRevisionStringCharacteristic');
var SoftwareRevisionStringCharacteristic = require('./Characteristics/SoftwareRevisionStringCharacteristic');
var SystemIDCharacteristic = require('./Characteristics/SystemIDCharacteristic');
var PnPIDCharacteristic = require('./Characteristics/PnPIDCharacteristic');

function DeviceInformationService() {
    bleno.PrimaryService.call(this, {
        uuid: '0000180A-0000-1000-8000-00805F9B34FB',
        characteristics: [
            new SerialNumberStringCharacteristic(),
            new HardwareRevisionStringCharacteristic(),
			new SoftwareRevisionStringCharacteristic(),
			new SystemIDCharacteristic(),
            new PnPIDCharacteristic()
        ]
    });
}

util.inherits(DeviceInformationService, bleno.PrimaryService);

module.exports = DeviceInformationService;
