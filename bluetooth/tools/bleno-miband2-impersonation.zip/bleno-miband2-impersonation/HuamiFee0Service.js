var util = require('util');
var bleno = require('bleno');

var CurrentTimeCharacteristic = require('./Characteristics/CurrentTimeCharacteristic');
var UnknownOneCharacteristic = require('./Characteristics/UnknownOneCharacteristic');
var UnknownTwoCharacteristic = require('./Characteristics/UnknownTwoCharacteristic');
var ConfigurationCharacteristic = require('./Characteristics/ConfigurationCharacteristic');
var HuamiPeripheralPreferredConnectionParametersCharacteristic = require('./Characteristics/HuamiPeripheralPreferredConnectionParametersCharacteristic');
var UnknownThreeCharacteristic = require('./Characteristics/UnknownThreeCharacteristic');
var ActivityDataCharacteristic = require('./Characteristics/ActivityDataCharacteristic');
var BatteryCharacteristic = require('./Characteristics/BatteryCharacteristic');
var StepsCharacteristic = require('./Characteristics/StepsCharacteristic');
var UserSettingsCharacteristic = require('./Characteristics/UserSettingsCharacteristic');
var DeviceEventCharacteristic = require('./Characteristics/DeviceEventCharacteristic');
var ChunkedTransferCharacteristic = require('./Characteristics/ChunkedTransferCharacteristic');
var UnknownFourCharacteristic = require('./Characteristics/UnknownFourCharacteristic');
var UnknownFiveCharacteristic = require('./Characteristics/UnknownFiveCharacteristic');
var UnknownSixCharacteristic = require('./Characteristics/UnknownSixCharacteristic');
var AudioCharacteristic = require('./Characteristics/AudioCharacteristic');
var AudioDataCharacteristic = require('./Characteristics/AudioDataCharacteristic');


function HuamiFee0Service() {
    bleno.PrimaryService.call(this, {
        uuid: '0000FEE0-0000-1000-8000-00805F9B34FB',
        characteristics: [
            new CurrentTimeCharacteristic(),
            new UnknownOneCharacteristic(),
			new UnknownTwoCharacteristic(),
			new ConfigurationCharacteristic(),
			new HuamiPeripheralPreferredConnectionParametersCharacteristic(),
			new UnknownThreeCharacteristic(),
			new ActivityDataCharacteristic(),
			new BatteryCharacteristic(),
			new StepsCharacteristic(),
			new UserSettingsCharacteristic(),
			new DeviceEventCharacteristic(),
			new ChunkedTransferCharacteristic(),
			new UnknownFourCharacteristic(),
			new UnknownFiveCharacteristic(),
			new UnknownSixCharacteristic(),
			new AudioCharacteristic(),
			new AudioDataCharacteristic()
        ]
    });
}

util.inherits(HuamiFee0Service, bleno.PrimaryService);

module.exports = HuamiFee0Service;
