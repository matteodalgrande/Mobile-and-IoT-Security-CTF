var util = require('util');
var bleno = require('bleno');

var AuthCharacteristic = require('./Characteristics/AuthCharacteristic');
var JawboneCharacteristic = require('./Characteristics/JawboneCharacteristic');
var CoinCharacteristic = require('./Characteristics/CoinCharacteristic');
var DesignShiftCharacteristic = require('./Characteristics/DesignShiftCharacteristic');
var AppleOneCharacteristic = require('./Characteristics/AppleOneCharacteristic');
var AppleTwoCharacteristic = require('./Characteristics/AppleTwoCharacteristic');
var AppleThreeCharacteristic = require('./Characteristics/AppleThreeCharacteristic');
var AppleFourCharacteristic = require('./Characteristics/AppleFourCharacteristic');
var KDDICorporationCharacteristic = require('./Characteristics/KDDICorporationCharacteristic');

function HuamiFee1Service() {
    bleno.PrimaryService.call(this, {
        uuid: '0000FEE1-0000-1000-8000-00805F9B34FB',
        characteristics: [
            new AuthCharacteristic(),
			new JawboneCharacteristic(),
			new CoinCharacteristic(),
			new DesignShiftCharacteristic(),
			new AppleOneCharacteristic(),
			new AppleTwoCharacteristic(),
			new AppleThreeCharacteristic(),
			new AppleFourCharacteristic(),
			new KDDICorporationCharacteristic()
	]
    });
}

util.inherits(HuamiFee1Service, bleno.PrimaryService);

module.exports = HuamiFee1Service;
