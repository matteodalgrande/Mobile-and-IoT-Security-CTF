Mi Band 2 - Tracker Impersonation

An implementation of a counterfeit Mi Band 2 using Bleno, a BLE perihperal Node.js library (https://github.com/noble/bleno).

Requirements: 
Bleno, Node.js, BLE adapter.

Usage: 
From terminal input "node main.js", you should be able to detect the new device from any BLE scanner.
You can pair the counterfeit device with a real Mi Fit app, by using the standard procedure.
