var util = require('util');
var bleno = require('bleno');

var DeviceNameCharacteristic = require('./Characteristics/DeviceNameCharacteristic');
var AppearanceCharacteristic = require('./Characteristics/AppearanceCharacteristic');
var PeripheralPreferredConnectionParametersCharacteristic = require('./Characteristics/PeripheralPreferredConnectionParametersCharacteristic');

function GenericAccessService() {
    bleno.PrimaryService.call(this, {
        uuid: '00001800-0000-1000-8000-00805F9B34FB',
        characteristics: [
            new DeviceNameCharacteristic(),
            new AppearanceCharacteristic(),
            new PeripheralPreferredConnectionParametersCharacteristic()
        ]
    });
}

util.inherits(GenericAccessService, bleno.PrimaryService);

module.exports = GenericAccessService;
