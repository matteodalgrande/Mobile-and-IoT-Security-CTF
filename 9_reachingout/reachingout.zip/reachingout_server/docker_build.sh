#!/bin/bash
docker build -t spritzers/reachingout_server .
