<html>
	<head>
		<title>Home</title>
		<meta charset='utf-8'/>
	</head>
	<body>
	<?php

	if ($_GET['username'] == "testuser" && $_GET['password'] == "passtestuser123") {
		echo "Here's your reward: FLAG{forma_bonum_fragile_est}";;
	} else {
		echo "Wrong parameters!";
	}
	?>
	</body>

</html>
					

	
